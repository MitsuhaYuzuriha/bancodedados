﻿
namespace _01_AulaCSharp
{
    partial class frmAprendendo
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAprendendo));
            this.lblTitulo = new System.Windows.Forms.Label();
            this.grpEscolha = new System.Windows.Forms.GroupBox();
            this.chkMysql = new System.Windows.Forms.CheckBox();
            this.chkCsharp = new System.Windows.Forms.CheckBox();
            this.chkSQL = new System.Windows.Forms.CheckBox();
            this.rdbSim = new System.Windows.Forms.RadioButton();
            this.rdbNao = new System.Windows.Forms.RadioButton();
            this.grpQueraprendercsharp = new System.Windows.Forms.GroupBox();
            this.gprCadastro = new System.Windows.Forms.GroupBox();
            this.txbsenha = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txbemail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txbNome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.mskFone = new System.Windows.Forms.MaskedTextBox();
            this.mskdata = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dgvtest = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.cbblinguagens = new System.Windows.Forms.ComboBox();
            this.lbllinguagem = new System.Windows.Forms.Label();
            this.tabBanco = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.msklogin = new System.Windows.Forms.MaskedTextBox();
            this.toolStripSalvar = new System.Windows.Forms.ToolStripButton();
            this.toolStripalterar = new System.Windows.Forms.ToolStripButton();
            this.toolStripexcluir = new System.Windows.Forms.ToolStripButton();
            this.toolStripCancel = new System.Windows.Forms.ToolStripButton();
            this.toolStripLogout = new System.Windows.Forms.ToolStripButton();
            this.toolStripSair = new System.Windows.Forms.ToolStripButton();
            this.picFoto = new System.Windows.Forms.PictureBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnCuidado = new System.Windows.Forms.Button();
            this.btnAtencao = new System.Windows.Forms.Button();
            this.btnOla = new System.Windows.Forms.Button();
            this.grpEscolha.SuspendLayout();
            this.grpQueraprendercsharp.SuspendLayout();
            this.gprCadastro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvtest)).BeginInit();
            this.tabBanco.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(12, 68);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(216, 31);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Aprendendo C#";
            // 
            // grpEscolha
            // 
            this.grpEscolha.Controls.Add(this.chkMysql);
            this.grpEscolha.Controls.Add(this.chkCsharp);
            this.grpEscolha.Controls.Add(this.chkSQL);
            this.grpEscolha.Location = new System.Drawing.Point(154, 113);
            this.grpEscolha.Name = "grpEscolha";
            this.grpEscolha.Size = new System.Drawing.Size(86, 100);
            this.grpEscolha.TabIndex = 6;
            this.grpEscolha.TabStop = false;
            this.grpEscolha.Text = "Escolha";
            // 
            // chkMysql
            // 
            this.chkMysql.AutoSize = true;
            this.chkMysql.Location = new System.Drawing.Point(7, 66);
            this.chkMysql.Name = "chkMysql";
            this.chkMysql.Size = new System.Drawing.Size(61, 17);
            this.chkMysql.TabIndex = 9;
            this.chkMysql.Text = "MySQL";
            this.chkMysql.UseVisualStyleBackColor = true;
            this.chkMysql.CheckedChanged += new System.EventHandler(this.chkMysql_CheckedChanged);
            // 
            // chkCsharp
            // 
            this.chkCsharp.AutoSize = true;
            this.chkCsharp.Location = new System.Drawing.Point(7, 43);
            this.chkCsharp.Name = "chkCsharp";
            this.chkCsharp.Size = new System.Drawing.Size(40, 17);
            this.chkCsharp.TabIndex = 8;
            this.chkCsharp.Text = "C#";
            this.chkCsharp.UseVisualStyleBackColor = true;
            this.chkCsharp.CheckedChanged += new System.EventHandler(this.chkCsharp_CheckedChanged);
            // 
            // chkSQL
            // 
            this.chkSQL.AutoSize = true;
            this.chkSQL.Location = new System.Drawing.Point(7, 20);
            this.chkSQL.Name = "chkSQL";
            this.chkSQL.Size = new System.Drawing.Size(47, 17);
            this.chkSQL.TabIndex = 0;
            this.chkSQL.Text = "SQL";
            this.chkSQL.UseVisualStyleBackColor = true;
            this.chkSQL.CheckedChanged += new System.EventHandler(this.chkSQL_CheckedChanged);
            // 
            // rdbSim
            // 
            this.rdbSim.AutoSize = true;
            this.rdbSim.Location = new System.Drawing.Point(20, 28);
            this.rdbSim.Name = "rdbSim";
            this.rdbSim.Size = new System.Drawing.Size(42, 17);
            this.rdbSim.TabIndex = 7;
            this.rdbSim.TabStop = true;
            this.rdbSim.Text = "Sim";
            this.rdbSim.UseVisualStyleBackColor = true;
            this.rdbSim.CheckedChanged += new System.EventHandler(this.rdbSim_CheckedChanged);
            // 
            // rdbNao
            // 
            this.rdbNao.AutoSize = true;
            this.rdbNao.Location = new System.Drawing.Point(20, 65);
            this.rdbNao.Name = "rdbNao";
            this.rdbNao.Size = new System.Drawing.Size(45, 17);
            this.rdbNao.TabIndex = 8;
            this.rdbNao.TabStop = true;
            this.rdbNao.Text = "Não";
            this.rdbNao.UseVisualStyleBackColor = true;
            this.rdbNao.CheckedChanged += new System.EventHandler(this.rdbNao_CheckedChanged);
            // 
            // grpQueraprendercsharp
            // 
            this.grpQueraprendercsharp.Controls.Add(this.rdbNao);
            this.grpQueraprendercsharp.Controls.Add(this.rdbSim);
            this.grpQueraprendercsharp.Location = new System.Drawing.Point(246, 113);
            this.grpQueraprendercsharp.Name = "grpQueraprendercsharp";
            this.grpQueraprendercsharp.Size = new System.Drawing.Size(117, 100);
            this.grpQueraprendercsharp.TabIndex = 9;
            this.grpQueraprendercsharp.TabStop = false;
            this.grpQueraprendercsharp.Text = "Quer aprender C#?";
            // 
            // gprCadastro
            // 
            this.gprCadastro.Controls.Add(this.msklogin);
            this.gprCadastro.Controls.Add(this.label9);
            this.gprCadastro.Controls.Add(this.mskdata);
            this.gprCadastro.Controls.Add(this.label5);
            this.gprCadastro.Controls.Add(this.mskFone);
            this.gprCadastro.Controls.Add(this.label4);
            this.gprCadastro.Controls.Add(this.txbsenha);
            this.gprCadastro.Controls.Add(this.label3);
            this.gprCadastro.Controls.Add(this.txbemail);
            this.gprCadastro.Controls.Add(this.label2);
            this.gprCadastro.Controls.Add(this.txbNome);
            this.gprCadastro.Controls.Add(this.label1);
            this.gprCadastro.Location = new System.Drawing.Point(154, 219);
            this.gprCadastro.Name = "gprCadastro";
            this.gprCadastro.Size = new System.Drawing.Size(209, 286);
            this.gprCadastro.TabIndex = 10;
            this.gprCadastro.TabStop = false;
            this.gprCadastro.Text = "Cadastro";
            // 
            // txbsenha
            // 
            this.txbsenha.Location = new System.Drawing.Point(10, 119);
            this.txbsenha.Name = "txbsenha";
            this.txbsenha.PasswordChar = '*';
            this.txbsenha.Size = new System.Drawing.Size(193, 20);
            this.txbsenha.TabIndex = 5;
            this.txbsenha.TextChanged += new System.EventHandler(this.txbsenha_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Senha:";
            // 
            // txbemail
            // 
            this.txbemail.Location = new System.Drawing.Point(10, 77);
            this.txbemail.Name = "txbemail";
            this.txbemail.Size = new System.Drawing.Size(193, 20);
            this.txbemail.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Email: ";
            // 
            // txbNome
            // 
            this.txbNome.Location = new System.Drawing.Point(10, 36);
            this.txbNome.Name = "txbNome";
            this.txbNome.Size = new System.Drawing.Size(193, 20);
            this.txbNome.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Fone:";
            // 
            // mskFone
            // 
            this.mskFone.Location = new System.Drawing.Point(10, 161);
            this.mskFone.Mask = "(00) 00000-0000";
            this.mskFone.Name = "mskFone";
            this.mskFone.Size = new System.Drawing.Size(193, 20);
            this.mskFone.TabIndex = 7;
            // 
            // mskdata
            // 
            this.mskdata.Location = new System.Drawing.Point(10, 209);
            this.mskdata.Mask = "00/00/0000";
            this.mskdata.Name = "mskdata";
            this.mskdata.Size = new System.Drawing.Size(193, 20);
            this.mskdata.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 190);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Data:";
            // 
            // dgvtest
            // 
            this.dgvtest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvtest.Location = new System.Drawing.Point(384, 120);
            this.dgvtest.Name = "dgvtest";
            this.dgvtest.Size = new System.Drawing.Size(449, 135);
            this.dgvtest.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(381, 297);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Linguagens";
            // 
            // cbblinguagens
            // 
            this.cbblinguagens.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbblinguagens.FormattingEnabled = true;
            this.cbblinguagens.Items.AddRange(new object[] {
            "HTML",
            "CSS",
            "Javascript",
            "PHP",
            "C#"});
            this.cbblinguagens.Location = new System.Drawing.Point(384, 314);
            this.cbblinguagens.Name = "cbblinguagens";
            this.cbblinguagens.Size = new System.Drawing.Size(121, 21);
            this.cbblinguagens.TabIndex = 13;
            this.cbblinguagens.SelectedIndexChanged += new System.EventHandler(this.cbblinguagens_SelectedIndexChanged);
            // 
            // lbllinguagem
            // 
            this.lbllinguagem.Location = new System.Drawing.Point(522, 314);
            this.lbllinguagem.Name = "lbllinguagem";
            this.lbllinguagem.Size = new System.Drawing.Size(100, 21);
            this.lbllinguagem.TabIndex = 14;
            // 
            // tabBanco
            // 
            this.tabBanco.Controls.Add(this.tabPage1);
            this.tabBanco.Controls.Add(this.tabPage2);
            this.tabBanco.Location = new System.Drawing.Point(384, 363);
            this.tabBanco.Name = "tabBanco";
            this.tabBanco.SelectedIndex = 0;
            this.tabBanco.Size = new System.Drawing.Size(453, 142);
            this.tabBanco.TabIndex = 15;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(445, 116);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "SQL Server";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(445, 116);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "My SQL";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(240, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "O SQL Server é um banco de dados da Microsoft";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(208, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "O MySQL é um banco de dados da Oracle";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSalvar,
            this.toolStripalterar,
            this.toolStripexcluir,
            this.toolStripCancel,
            this.toolStripLogout,
            this.toolStripSair});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(846, 54);
            this.toolStrip1.TabIndex = 16;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 235);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "Login:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(543, 262);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(177, 117);
            this.label10.TabIndex = 17;
            this.label10.Text = resources.GetString("label10.Text");
            // 
            // msklogin
            // 
            this.msklogin.Location = new System.Drawing.Point(10, 251);
            this.msklogin.Mask = "LLLLLLLLLL";
            this.msklogin.Name = "msklogin";
            this.msklogin.Size = new System.Drawing.Size(193, 20);
            this.msklogin.TabIndex = 11;
            // 
            // toolStripSalvar
            // 
            this.toolStripSalvar.Image = global::_01_AulaCSharp.Properties.Resources.save_32;
            this.toolStripSalvar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSalvar.Name = "toolStripSalvar";
            this.toolStripSalvar.Size = new System.Drawing.Size(42, 51);
            this.toolStripSalvar.Text = "Salvar";
            this.toolStripSalvar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripSalvar.Click += new System.EventHandler(this.toolStripSalvar_Click);
            // 
            // toolStripalterar
            // 
            this.toolStripalterar.Enabled = false;
            this.toolStripalterar.Image = global::_01_AulaCSharp.Properties.Resources.update_32;
            this.toolStripalterar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripalterar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripalterar.Name = "toolStripalterar";
            this.toolStripalterar.Size = new System.Drawing.Size(46, 51);
            this.toolStripalterar.Text = "Alterar";
            this.toolStripalterar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripexcluir
            // 
            this.toolStripexcluir.Enabled = false;
            this.toolStripexcluir.Image = global::_01_AulaCSharp.Properties.Resources.delete_32;
            this.toolStripexcluir.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripexcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripexcluir.Name = "toolStripexcluir";
            this.toolStripexcluir.Size = new System.Drawing.Size(46, 51);
            this.toolStripexcluir.Text = "Excluir";
            this.toolStripexcluir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripCancel
            // 
            this.toolStripCancel.Image = global::_01_AulaCSharp.Properties.Resources.cancel_32;
            this.toolStripCancel.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripCancel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripCancel.Name = "toolStripCancel";
            this.toolStripCancel.Size = new System.Drawing.Size(57, 51);
            this.toolStripCancel.Text = "Cancelar";
            this.toolStripCancel.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.toolStripCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripCancel.Visible = false;
            this.toolStripCancel.Click += new System.EventHandler(this.toolStripCancel_Click);
            // 
            // toolStripLogout
            // 
            this.toolStripLogout.Image = global::_01_AulaCSharp.Properties.Resources.logout_32;
            this.toolStripLogout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripLogout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripLogout.Name = "toolStripLogout";
            this.toolStripLogout.Size = new System.Drawing.Size(49, 51);
            this.toolStripLogout.Text = "Logout";
            this.toolStripLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripSair
            // 
            this.toolStripSair.Image = global::_01_AulaCSharp.Properties.Resources.exit_32;
            this.toolStripSair.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSair.Name = "toolStripSair";
            this.toolStripSair.Size = new System.Drawing.Size(36, 51);
            this.toolStripSair.Text = "Sair";
            this.toolStripSair.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripSair.Click += new System.EventHandler(this.toolStripSair_Click);
            // 
            // picFoto
            // 
            this.picFoto.Image = global::_01_AulaCSharp.Properties.Resources.csharp;
            this.picFoto.Location = new System.Drawing.Point(18, 383);
            this.picFoto.Name = "picFoto";
            this.picFoto.Size = new System.Drawing.Size(116, 122);
            this.picFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picFoto.TabIndex = 5;
            this.picFoto.TabStop = false;
            // 
            // btnSair
            // 
            this.btnSair.Image = global::_01_AulaCSharp.Properties.Resources.sair;
            this.btnSair.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSair.Location = new System.Drawing.Point(18, 317);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(116, 60);
            this.btnSair.TabIndex = 4;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnCuidado
            // 
            this.btnCuidado.Image = global::_01_AulaCSharp.Properties.Resources.cuidado;
            this.btnCuidado.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCuidado.Location = new System.Drawing.Point(18, 251);
            this.btnCuidado.Name = "btnCuidado";
            this.btnCuidado.Size = new System.Drawing.Size(116, 60);
            this.btnCuidado.TabIndex = 3;
            this.btnCuidado.Text = "Cuidado";
            this.btnCuidado.UseVisualStyleBackColor = true;
            this.btnCuidado.Click += new System.EventHandler(this.btnCuidado_Click);
            // 
            // btnAtencao
            // 
            this.btnAtencao.Image = global::_01_AulaCSharp.Properties.Resources.atencao;
            this.btnAtencao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAtencao.Location = new System.Drawing.Point(18, 185);
            this.btnAtencao.Name = "btnAtencao";
            this.btnAtencao.Size = new System.Drawing.Size(116, 60);
            this.btnAtencao.TabIndex = 2;
            this.btnAtencao.Text = "Atenção";
            this.btnAtencao.UseVisualStyleBackColor = true;
            this.btnAtencao.Click += new System.EventHandler(this.btnAtencao_Click);
            // 
            // btnOla
            // 
            this.btnOla.Image = global::_01_AulaCSharp.Properties.Resources.ola;
            this.btnOla.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOla.Location = new System.Drawing.Point(18, 119);
            this.btnOla.Name = "btnOla";
            this.btnOla.Size = new System.Drawing.Size(116, 60);
            this.btnOla.TabIndex = 1;
            this.btnOla.Text = "Olá";
            this.btnOla.UseVisualStyleBackColor = true;
            this.btnOla.Click += new System.EventHandler(this.btnOla_Click);
            // 
            // frmAprendendo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(846, 558);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.tabBanco);
            this.Controls.Add(this.lbllinguagem);
            this.Controls.Add(this.cbblinguagens);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dgvtest);
            this.Controls.Add(this.gprCadastro);
            this.Controls.Add(this.grpQueraprendercsharp);
            this.Controls.Add(this.grpEscolha);
            this.Controls.Add(this.picFoto);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnCuidado);
            this.Controls.Add(this.btnAtencao);
            this.Controls.Add(this.btnOla);
            this.Controls.Add(this.lblTitulo);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAprendendo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aprendendo C#";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAprendendo_FormClosing);
            this.Load += new System.EventHandler(this.frmAprendendo_Load);
            this.grpEscolha.ResumeLayout(false);
            this.grpEscolha.PerformLayout();
            this.grpQueraprendercsharp.ResumeLayout(false);
            this.grpQueraprendercsharp.PerformLayout();
            this.gprCadastro.ResumeLayout(false);
            this.gprCadastro.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvtest)).EndInit();
            this.tabBanco.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnOla;
        private System.Windows.Forms.Button btnAtencao;
        private System.Windows.Forms.Button btnCuidado;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.PictureBox picFoto;
        private System.Windows.Forms.GroupBox grpEscolha;
        private System.Windows.Forms.CheckBox chkMysql;
        private System.Windows.Forms.CheckBox chkCsharp;
        private System.Windows.Forms.CheckBox chkSQL;
        private System.Windows.Forms.RadioButton rdbSim;
        private System.Windows.Forms.RadioButton rdbNao;
        private System.Windows.Forms.GroupBox grpQueraprendercsharp;
        private System.Windows.Forms.GroupBox gprCadastro;
        private System.Windows.Forms.TextBox txbsenha;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txbemail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txbNome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox mskdata;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox mskFone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgvtest;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbblinguagens;
        private System.Windows.Forms.Label lbllinguagem;
        private System.Windows.Forms.TabControl tabBanco;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripSalvar;
        private System.Windows.Forms.MaskedTextBox msklogin;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ToolStripButton toolStripalterar;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ToolStripButton toolStripexcluir;
        private System.Windows.Forms.ToolStripButton toolStripCancel;
        private System.Windows.Forms.ToolStripButton toolStripLogout;
        private System.Windows.Forms.ToolStripButton toolStripSair;
    }
}

