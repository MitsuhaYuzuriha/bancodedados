﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _01_AulaCSharp
{
    public partial class frmAprendendo : Form
    {
        public frmAprendendo()
        {
            InitializeComponent();
        }

        private void btnOla_Click(object sender, EventArgs e)
        {
            // Caixa de mensagem: Mensagem, Titulo, botão e ícone
            MessageBox.Show("Olá usuário, seja bem vindo(a)!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnAtencao_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Atenção!!!\nNão falte nas aulas de C#", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void btnCuidado_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cuidado!!!\nNão faça cocozinho no codigo", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            DialogResult Sair = MessageBox.Show("Deseja sair do Programa?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            Application.Exit();
        }

        private void frmAprendendo_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult Sair = MessageBox.Show("Deseja sair do Programa?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Sair == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void rdbSim_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbSim.Checked == true)
            {
                MessageBox.Show("Boa escolha", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void chkSQL_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSQL.Checked == true)
            {
                MessageBox.Show("Você marcou o SQL Server", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Você desmarcou o SQL Server", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void chkCsharp_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCsharp.Checked == true)
            {
                MessageBox.Show("Você marcou o C# Server", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Você desmarcou o C# Server", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void chkMysql_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMysql.Checked == true)
            {
                MessageBox.Show("Você marcou o MySQL Server", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Você desmarcou o C# Server", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void rdbNao_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbNao.Checked == true)
            {
                MessageBox.Show("Putz...", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txbsenha_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmAprendendo_Load(object sender, EventArgs e)
        {
            //adicionando itens no combobox
            cbblinguagens.Items.Add("Java");
            cbblinguagens.Items.Add("JQuery");
            cbblinguagens.Items.Add("Pear");

            //adicionando as colunas no datagrid
            dgvtest.Columns.Add("codigo", "Código");
            dgvtest.Columns.Add("nome", "Nome");
            dgvtest.Columns.Add("preco", "Preço");
            dgvtest.Columns.Add("data", "Data");

            //alinhando as colunas
            dgvtest.Columns["codigo"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvtest.Columns["preco"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            // laço para preencher as linhas do datagrid
            for (int cont = 1; cont < 100; cont++)
            {
                //cria uma linha 
                DataGridViewRow item = new DataGridViewRow();
                item.CreateCells(dgvtest);

                // seta os valores
                item.Cells[0].Value = cont;
                item.Cells[1].Value = "Produto" + cont;
                item.Cells[2].Value = 10.50;
                item.Cells[3].Value = DateTime.Today;

                // add as linhas no datagrid
                dgvtest.Rows.Add(item);
            }
        }

        private void cbblinguagens_SelectedIndexChanged(object sender, EventArgs e)
        {
            // label recebe o texto do combobox
            lbllinguagem.Text = cbblinguagens.Text;
        }

        private void toolStripSalvar_Click(object sender, EventArgs e)
        {
            toolStripCancel.Visible = true;
            toolStripSalvar.Enabled = false;
        }

        private void toolStripCancel_Click(object sender, EventArgs e)
        {
            toolStripCancel.Visible = false;
            toolStripSalvar.Visible = true;
        }

        private void toolStripSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
